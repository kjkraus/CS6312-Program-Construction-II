package edu.westga.cs6312.zuul.controller;

/**
 * This class contains the entry point of the application
 * 
 * @author
 * 
 * @version
 */
public class ZuulDriver {

	/**
	 * The entry point of the application
	 * @param args	Used to accept command line arguments
	 */
	public static void main(String[] args) {
		// TODO Add code to create an instance of the Game object and call play
	}
}
